DATA.BGIMG = new Image(`${DATA.THEME_PATH}bg/bg.jpg`);
DATA.BGIMG.optimize();
DATA.BGIMG.filter = LINEAR;
DATA.DISPLAYBG = true;
